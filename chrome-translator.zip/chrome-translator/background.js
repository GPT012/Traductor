// Background Service Worker - Auto Translator (Google Translate GRATUIT)

const DEFAULT_CONFIG = {
    targetLang: 'en',
    sourceLang: 'auto',
    enabled: true
};

async function getConfig() {
    const result = await chrome.storage.local.get(['targetLang', 'sourceLang', 'enabled']);
    return { ...DEFAULT_CONFIG, ...result };
}

async function saveConfig(config) {
    await chrome.storage.local.set(config);
}

// Traduction gratuite via Google Translate API publique
async function translateText(text, targetLang = 'en', sourceLang = 'auto') {
    if (!text || text.trim().length === 0) {
        return { error: "Texte vide" };
    }

    try {
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sourceLang}&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`;

        console.log('[Translator] Appel Google Translate:', { text, targetLang, sourceLang });

        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();

        // Google retourne un tableau de tableaux avec les traductions
        let translation = '';
        if (data && data[0]) {
            for (const part of data[0]) {
                if (part[0]) {
                    translation += part[0];
                }
            }
        }

        if (translation) {
            console.log('[Translator] ✅ Traduit:', translation);
            return { translation };
        } else {
            return { error: "Pas de traduction reçue" };
        }

    } catch (error) {
        console.error('[Translator] Erreur:', error);
        return { error: error.message };
    }
}

// Écouter les messages
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('[Translator] Message reçu:', request.action);

    if (request.action === 'getStatus') {
        getConfig().then(config => {
            sendResponse({ enabled: config.enabled, targetLang: config.targetLang });
        });
        return true;
    }

    if (request.action === 'toggle') {
        saveConfig({ enabled: request.enabled }).then(() => {
            chrome.tabs.query({}, (tabs) => {
                tabs.forEach(tab => {
                    chrome.tabs.sendMessage(tab.id, { action: 'statusChanged', enabled: request.enabled }).catch(() => { });
                });
            });
            sendResponse({ enabled: request.enabled });
        });
        return true;
    }

    if (request.action === 'setTargetLang') {
        saveConfig({ targetLang: request.lang }).then(() => {
            sendResponse({ targetLang: request.lang });
        });
        return true;
    }

    if (request.action === 'translate') {
        getConfig().then(config => {
            translateText(request.text, config.targetLang, config.sourceLang).then(result => {
                sendResponse(result);
            });
        });
        return true;
    }

    if (request.action === 'getConfig') {
        getConfig().then(config => {
            sendResponse(config);
        });
        return true;
    }
});

console.log('[Translator] ✅ Service Worker démarré (Google Translate GRATUIT)');
