document.addEventListener('DOMContentLoaded', () => {
    const toggle = document.getElementById('toggleEnabled');
    const targetLangSelect = document.getElementById('targetLang');

    // Récupérer l'état actuel
    chrome.runtime.sendMessage({ action: 'getConfig' }, (config) => {
        if (config) {
            toggle.checked = config.enabled !== false;
            if (config.targetLang) targetLangSelect.value = config.targetLang;
        }
    });

    // Toggle
    toggle.addEventListener('change', () => {
        chrome.runtime.sendMessage({ action: 'toggle', enabled: toggle.checked });
    });

    // Changement de langue
    targetLangSelect.addEventListener('change', () => {
        chrome.runtime.sendMessage({ action: 'setTargetLang', lang: targetLangSelect.value });
    });
});
