// Content script - Auto Translator v4
// Avec SCRAPING ACTIF de toutes les zones de saisie

(function () {
    'use strict';

    console.log('%c🌐 AUTO TRANSLATOR v4', 'background: #667eea; color: white; font-size: 16px; padding: 10px;');

    let isEnabled = true;
    let activeField = null;
    let timer = null;
    const DELAY = 2000;

    // === CSS ===
    const style = document.createElement('style');
    style.id = 'translator-styles';
    style.textContent = `
    .translator-found { outline: 2px dashed rgba(102, 126, 234, 0.4) !important; }
    .translator-active { outline: 3px solid rgba(102, 126, 234, 0.6) !important; animation: translator-glow 1s ease-in-out infinite; }
    .translator-waiting { outline: 3px solid rgba(240, 147, 251, 0.8) !important; }
    .translator-working { outline: 3px solid rgba(245, 175, 25, 0.9) !important; animation: translator-pulse 0.5s ease-in-out infinite; }
    .translator-done { outline: 3px solid rgba(17, 153, 142, 0.8) !important; }
    @keyframes translator-glow { 0%, 100% { outline-color: rgba(102, 126, 234, 0.6); } 50% { outline-color: rgba(102, 126, 234, 0.3); } }
    @keyframes translator-pulse { 0%, 100% { outline-width: 3px; } 50% { outline-width: 5px; } }
    #translator-badge {
      all: initial !important;
      position: fixed !important;
      bottom: 20px !important;
      right: 20px !important;
      padding: 12px 18px !important;
      background: linear-gradient(135deg, #667eea, #764ba2) !important;
      color: white !important;
      font: bold 14px -apple-system, BlinkMacSystemFont, sans-serif !important;
      border-radius: 25px !important;
      box-shadow: 0 4px 20px rgba(102, 126, 234, 0.5) !important;
      z-index: 2147483647 !important;
      cursor: pointer !important;
      transition: all 0.3s !important;
      display: flex !important;
      align-items: center !important;
      gap: 6px !important;
    }
    #translator-badge:hover { transform: scale(1.05) !important; }
    #translator-count {
      background: rgba(255,255,255,0.3) !important;
      padding: 2px 8px !important;
      border-radius: 10px !important;
      font-size: 11px !important;
    }
  `;

    // === BADGE ===
    const badge = document.createElement('div');
    badge.id = 'translator-badge';
    badge.innerHTML = '🌐 ON <span id="translator-count">0</span>';

    function updateBadge(state, text, count) {
        const colors = {
            on: 'linear-gradient(135deg, #667eea, #764ba2)',
            off: 'linear-gradient(135deg, #6c757d, #495057)',
            typing: 'linear-gradient(135deg, #11998e, #38ef7d)',
            waiting: 'linear-gradient(135deg, #f093fb, #f5576c)',
            working: 'linear-gradient(135deg, #f5af19, #f12711)',
            done: 'linear-gradient(135deg, #11998e, #38ef7d)',
            error: 'linear-gradient(135deg, #cb2d3e, #ef473a)'
        };
        badge.style.background = colors[state] || colors.on;
        const countEl = document.getElementById('translator-count');
        if (count !== undefined && countEl) countEl.textContent = count;
        if (text) {
            badge.innerHTML = text + (countEl ? ` <span id="translator-count">${count || ''}</span>` : '');
        }
    }

    badge.onclick = () => {
        isEnabled = !isEnabled;
        updateBadge(isEnabled ? 'on' : 'off', isEnabled ? '🌐 ON' : '⏸️ OFF');
        if (isEnabled) scanForInputs();
    };

    // === SCRAPING ACTIF - TROUVER TOUTES LES ZONES DE SAISIE ===
    function scanForInputs() {
        // Supprimer les anciens surlignages
        document.querySelectorAll('.translator-found').forEach(el => el.classList.remove('translator-found'));

        const inputs = [];

        // 1. Tous les inputs texte
        document.querySelectorAll('input[type="text"], input[type="search"], input[type="email"], input[type="url"], input:not([type])').forEach(el => {
            if (!el.disabled && !el.readOnly) inputs.push(el);
        });

        // 2. Tous les textareas
        document.querySelectorAll('textarea').forEach(el => {
            if (!el.disabled && !el.readOnly) inputs.push(el);
        });

        // 3. Tous les contenteditable
        document.querySelectorAll('[contenteditable="true"]').forEach(el => inputs.push(el));

        // 4. Éléments avec role textbox/searchbox
        document.querySelectorAll('[role="textbox"], [role="searchbox"], [role="combobox"]').forEach(el => inputs.push(el));

        // 5. Divs éditables (Google Docs, etc.)
        document.querySelectorAll('div[aria-label*="earch"], div[aria-label*="essage"], div[aria-label*="ype"]').forEach(el => inputs.push(el));

        // Supprimer les doublons
        const unique = [...new Set(inputs)];

        console.log(`🌐 Trouvé ${unique.length} zones de saisie:`, unique);

        // Marquer visuellement toutes les zones
        unique.forEach(el => el.classList.add('translator-found'));

        updateBadge('on', '🌐 ON', unique.length);

        return unique;
    }

    // === FONCTIONS ===
    function getValue(el) {
        if (el.value !== undefined) return el.value;
        return el.innerText || el.textContent || '';
    }

    function setValue(el, text) {
        if (el.value !== undefined) {
            el.value = text;
            el.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
            el.innerText = text;
            el.dispatchEvent(new InputEvent('input', { bubbles: true, data: text }));
        }
    }

    function setClass(el, cls) {
        el.classList.remove('translator-found', 'translator-active', 'translator-waiting', 'translator-working', 'translator-done');
        if (cls) el.classList.add('translator-' + cls);
    }

    // === TRADUCTION ===
    function translate(el) {
        const text = getValue(el).trim();
        if (!text || text.length < 2) {
            setClass(el, 'found');
            updateBadge('on', '🌐 ON');
            return;
        }

        console.log('🌐 Traduction de:', text);
        setClass(el, 'working');
        updateBadge('working', '🔄 Traduction...');

        chrome.runtime.sendMessage({ action: 'translate', text }, (res) => {
            if (chrome.runtime.lastError) {
                console.error('🌐 Erreur:', chrome.runtime.lastError);
                setClass(el, 'found');
                updateBadge('error', '❌ Erreur');
                setTimeout(() => updateBadge('on', '🌐 ON'), 2000);
                return;
            }

            if (res && res.translation) {
                console.log('🌐 ✅ Traduction:', res.translation);
                setValue(el, res.translation);
                setClass(el, 'done');
                updateBadge('done', '✅ ' + res.translation.slice(0, 20));
                setTimeout(() => {
                    setClass(el, 'found');
                    updateBadge('on', '🌐 ON');
                }, 2500);
            } else if (res && res.error) {
                console.error('🌐 Erreur API:', res.error);
                updateBadge('error', '❌ ' + res.error.slice(0, 25));
                setTimeout(() => updateBadge('on', '🌐 ON'), 3000);
            }
        });
    }

    // === ÉVÉNEMENTS ===
    function handleInput(e) {
        const el = e.target;
        if (!isEnabled) return;

        // Vérifier si c'est une zone de saisie
        const isInput = el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' ||
            el.isContentEditable || el.contentEditable === 'true' ||
            el.getAttribute('role') === 'textbox';

        if (!isInput) return;

        console.log('🌐 Input détecté:', el.tagName, getValue(el).slice(0, 30));

        activeField = el;
        setClass(el, 'active');
        updateBadge('typing', '⌨️ Typing...');

        clearTimeout(timer);

        timer = setTimeout(() => {
            setClass(el, 'waiting');
            updateBadge('waiting', '⏳ 2s...');
        }, 800);

        timer = setTimeout(() => translate(el), DELAY);
    }

    // Écouter sur document avec capture
    document.addEventListener('input', handleInput, true);
    document.addEventListener('keyup', handleInput, true);

    // Focus - pour détecter la zone active
    document.addEventListener('focus', (e) => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable) {
            console.log('🌐 Focus sur:', e.target.tagName);
            setClass(e.target, 'active');
        }
    }, true);

    // === INIT ===
    function init() {
        if (document.getElementById('translator-styles')) return;

        (document.head || document.documentElement).appendChild(style);
        (document.body || document.documentElement).appendChild(badge);

        // Scanner la page pour trouver les zones de saisie
        const count = scanForInputs().length;
        console.log(`🌐 ✅ Initialisé - ${count} zones trouvées`);

        // Re-scanner périodiquement pour les éléments dynamiques
        setInterval(scanForInputs, 5000);
    }

    // Exécuter
    if (document.readyState === 'complete') {
        init();
    } else {
        window.addEventListener('load', init);
    }

    // Fallbacks
    setTimeout(init, 500);
    setTimeout(init, 2000);

})();
